from ClaseProducto import Producto


class Congelado(Producto):
    __nitrogeno = int
    __oxigeno = int
    __dioxido = int
    __vapor = int
    __metodo = str

    def __init__(self, n, fechaE, fechaV, t, p, l, c, nitr, oxi, dio, vap, metodo):
        super().__init__(n, fechaE, fechaV, t, p, l, c)
        self.__nitrogeno = nitr
        self.__oxigeno = oxi
        self.__dioxido = dio
        self.__vapor = vap
        self.__metodo = metodo

    def Importe(self, a):
        importe = self.getprecio() * 0.15
        nuevo = self.getprecio() + importe
        return nuevo
