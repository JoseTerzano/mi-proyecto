import csv
from ClaseProdCong import Congelado
from ClaseProdRefri import Refrigerado


class Lista:
    __lista = list

    def __init__(self):
        self.__lista = []

    def Cargar(self):
        archivo = open("productos.csv")
        reader = csv.reader(archivo, delimiter=";")
        for fila in reader:
            if fila[0] == "C":
                nuevocongelado = Congelado(fila[1], fila[2], fila[3], float(fila[4]), fila[5], fila[6], int(
                    fila[7]), int(fila[8]), int(fila[9]), int(fila[10]), int(fila[11]), fila[12])
                self.__lista.append(nuevocongelado)
            elif fila[0] == "R":
                nuevorefrigerado = Refrigerado(fila[1], fila[2], fila[3], float(fila[4]), fila[5], fila[6], int(
                    fila[7]), fila[8])
                self.__lista.append(nuevorefrigerado)
        archivo.close()

    def Agregar(self):
        tipo = input("Ingrese tipo de producto: ")
        nombre = input("Ingrese nombre de producto: ")
        fechaEn = input("Ingrese fecha de envasado de producto: ")
        fechaVen = input("Ingrese fecha de vencimiento de producto: ")
        tem = float(
            input("Ingrese temperatura recomendada de mantenimiento de producto: "))
        pais = input("Ingrese pais de origen de producto: ")
        lote = input("Ingrese lote de producto: ")
        costoB = input("Ingrese costo base de producto: ")
        if tipo == "C":
            nit = int(input("Ingrese cantidad de nitrogeno de producto: "))
            oxi = int(input("Ingrese cantidad de oxigeno de producto: "))
            dio = int(
                input("Ingrese cantidad de dioxido de carbono de producto: "))
            vap = int(input("Ingrese cantidad de vapor de agua de producto: "))
            met = input("Ingrese metodo del producto")
            nuevocongelado = Congelado(
                nombre, fechaEn, fechaVen, tem, pais, lote, costoB, nit, oxi, dio, vap, met)
            self.__lista.append(nuevocongelado)
        elif tipo == "R":
            cod = input(
                "Ingrese codigo de organismo de supervision de producto: ")
            nuevorefrigerado = Refrigerado(
                nombre, fechaEn, fechaVen, tem, pais, lote, costoB, cod)
            self.__lista.append(nuevorefrigerado)

    def Buscar(self, pos):
        if pos >= len(self.__lista) or pos < 0:
            print("posicion fuera de rango")
        else:
            p = self.__lista[pos]
        if isinstance(p, Congelado):
            print("El producto buscado es Congelado")
        elif isinstance(p, Refrigerado):
            print("La producto buscado es Refrigerado")

    def MostrarCantidad(self):
        cantrefr = 0
        cantcong = 0
        for i in range(len(self.__lista)):
            if isinstance(self.__lista[i], Refrigerado):
                cantrefr += 1
            elif isinstance(self.__lista[i], Congelado):
                cantcong += 1
        print(f"La cantidad de productos Congelados es: {
              cantcong}\n La cantidad de productos refrigerados es: {cantrefr}")

    def Recorrer(self, a):
        for obj in self.__lista:
            print(obj.getnombre())
            print(obj.getpais())
            print(obj.gettemp())
            print(obj.Importe(a))
