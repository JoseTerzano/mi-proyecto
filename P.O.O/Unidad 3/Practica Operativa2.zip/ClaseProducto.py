class Producto:
    __nombre = str
    __fechaEnv = str
    __fechaVen = str
    __temperatura = float
    __pais = str
    __lote = str
    __costoBase = int

    def __init__(self, n, fechaE, fechaV, t, p, l, c):
        self.__nombre = n
        self.__fechaEnv = fechaE
        self.__fechaVen = fechaV
        self.__temperatura = t
        self.__pais = p
        self.__lote = l
        self.__costoBase = c

    def getnombre(self):
        return self.__nombre

    def getpais(self):
        return self.__pais

    def gettemp(self):
        return self.__temperatura

    def getprecio(self):
        return self.__costoBase

    def getfecha(self):
        return self.__fechaVen

    def Importe(self):
        pass
