from Gestor import Lista

if __name__ == "__main__":
    lista = Lista()
    lista.Cargar()
    a = int(input(" 1. Agregar Producto \n 2. Mostrar Producto \n 3. Mostrar Cantidad \n 4. Recorrer y Mostrar Datos \n 0. Para Finalizar \n Su Opcion: "))
    while a != 0:
        if a == 1:
            lista.Agregar()
        if a == 2:
            pos = int(input("Ingrese posicion: "))
            lista.Buscar(pos)
        if a == 3:
            lista.MostrarCantidad()
        if a == 4:
            a = int(input("Ingrese fecha en numero: "))
            lista.Recorrer(a)
        a = int(input(" 1. Agregar Producto \n 2. Mostrar Producto \n 3. Mostrar Cantidad \n 4. Recorrer y Mostrar Datos \n 0. Para Finalizar \n Su Opcion: "))
