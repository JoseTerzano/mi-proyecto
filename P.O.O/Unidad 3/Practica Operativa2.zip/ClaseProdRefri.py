from ClaseProducto import Producto


class Refrigerado(Producto):
    __cod = str

    def __init__(self, n, fechaE, fechaV, t, p, l, c, cod):
        super().__init__(n, fechaE, fechaV, t, p, l, c)
        self.__cod = cod

    def Importe(self, fecha):
        if (fecha - 5) > 2:
            nuevo = self.getprecio() * 0.01
            imp = self.getprecio() + nuevo
            return imp
        elif (fecha - 5) <= 2:
            nuevo = self.getprecio() * 0.1
            imp = self.getprecio() - nuevo
            return imp
